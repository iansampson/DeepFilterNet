#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <complex.h>

void analysis(const float *input, const float complex *output, uintptr_t length);
